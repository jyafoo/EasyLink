import{_ as e,d as c,e as n}from"./index-2ef5d94b.js";const r={};function t(o,s){return c(),n("div",null," 回收站 ")}const a=e(r,[["render",t]]);export{a as default};
